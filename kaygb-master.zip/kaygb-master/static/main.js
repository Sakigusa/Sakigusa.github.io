// JS监听设置网站背景
window.onload = function() {
    setTimeout(function() {

        // document.body.style.background = "url(https://acg.wgb.ink/acgurl.php)";
    }, 2e3);

}