## 全新版本已经发布

仓库：https://github.com/kaygb/KZHomePage
使用教程：https://blog.170601.xyz/archives/25.html

> 当前版本不再维护，请关注新仓库
